import{j as s}from"./index-B4ohKdrB.js";function i(){return s.jsx("div",{className:"saved-businesses",style:{padding:"2rem"},children:s.jsx("h1",{children:"Saved Businesses"})})}export{i as default};
