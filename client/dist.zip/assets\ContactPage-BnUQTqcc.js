import{j as t}from"./index-B4ohKdrB.js";function e(){return t.jsx("div",{className:"contact-page",style:{padding:"2rem"},children:t.jsx("h1",{children:"Contact"})})}export{e as default};
