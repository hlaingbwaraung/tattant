import{j as e}from"./index-B4ohKdrB.js";function r(){return e.jsx("div",{className:"faq-page",style:{padding:"2rem"},children:e.jsx("h1",{children:"FAQ"})})}export{r as default};
